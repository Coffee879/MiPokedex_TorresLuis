# Rama `compose`

## 1. Git
```bash
git checkout -b compose
# copia la carpeta app/src/main/java/... de este paquete sobre tu proyecto
git rm app/src/main/res/layout/activity_main.xml \
       app/src/main/res/drawable/fondo.xml \
       app/src/main/res/drawable/fondop.xml \
       app/src/main/res/values/styles.xml
git add -A
git commit -m "Migrar vista de la Pokedex a Jetpack Compose con composables propios"
git push -u origin compose
```

## 2. Gradle (app/build.gradle.kts)
```kotlin
plugins {
    // ...los que ya tienes
    id("org.jetbrains.kotlin.plugin.compose")   // misma versión que tu Kotlin (2.x)
}
android {
    buildFeatures { compose = true }
}
dependencies {
    val bom = platform("androidx.compose:compose-bom:<ultima-version>")
    implementation(bom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.activity:activity-compose:<ultima-version>")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
```
(En el build.gradle.kts raíz agrega el mismo plugin con `apply false`.)
Ya no necesitas `constraintlayout` ni `appcompat` si nada más los usa.

## 3. Manifest
Sin cambios: `MainActivity` ahora hereda de `ComponentActivity`, así que el tema actual sirve.
