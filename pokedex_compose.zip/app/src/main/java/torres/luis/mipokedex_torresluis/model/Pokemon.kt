package torres.luis.mipokedex_torresluis.model

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Immutable
import torres.luis.mipokedex_torresluis.R

/** @Immutable permite a Compose omitir recomposiciones si el objeto no cambia. */
@Immutable
data class Pokemon(
    val dexNumber: Int,
    val name: String,
    val type: String,
    val height: String,
    val weight: String,
    val ability: String,
    val description: String,
    @DrawableRes val image: Int,
) {
    // Se calculan una sola vez al crear el objeto, no en cada recomposición.
    val number: String = "#$dexNumber"
    val navLabel: String = "$name N. ${dexNumber.toString().padStart(4, '0')}"
}

val SamplePokemon = listOf(
    Pokemon(6, "Charizard", "fuego / volador", "1,7 m", "90,5 kg", "mar llamas",
        "escupe fuego tan caliente que puede derretir rocas", R.drawable.charizard),
    Pokemon(358, "Chimecho", "psiquico", "0,6 m", "1,0 kg", "levitacion",
        "emite gritos ultrasonicos, puede volar gracias a las ondas que produce al mover su cuerpo", R.drawable.chimecho),
    Pokemon(7, "Squirtle", "agua", "0,5 m", "9,0 kg", "torrente",
        "se esconde en su caparazon y dispara agua a presion", R.drawable.squirtle),
)
