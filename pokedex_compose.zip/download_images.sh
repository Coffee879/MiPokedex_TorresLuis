#!/bin/bash
# Ejecutar desde la raíz del proyecto Android (donde está la carpeta app/).
# Descarga las imágenes oficiales del Pokédex y las guarda con el nombre del Pokémon.
# Squirtle no se descarga: ya tienes squirtle.jpg en res/drawable.
DEST=app/src/main/res/drawable
mkdir -p "$DEST"
declare -A IDS=( [bulbasaur]=001 [charmander]=004 [pikachu]=025 [jigglypuff]=039
                 [gengar]=094 [snorlax]=143 [mewtwo]=150 [lucario]=448 [mimikyu]=778 )
for name in "${!IDS[@]}"; do
  curl -fL -o "$DEST/$name.png" "https://assets.pokemon.com/assets/cms2/img/pokedex/full/${IDS[$name]}.png" \
    && echo "OK  $name" || echo "FALLÓ $name (descárgalo a mano desde pokemon.com/el/pokedex)"
done
